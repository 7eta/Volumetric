#!/bin/sh

./testgldispatchthread

