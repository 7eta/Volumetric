#!/bin/sh

. $TOP_SRCDIR/tests/eglenv.sh

./testeglcurrentcleanup -m -t -k -r
