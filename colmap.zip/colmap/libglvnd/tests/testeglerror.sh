#!/bin/sh

. $TOP_SRCDIR/tests/eglenv.sh

./testeglerror
