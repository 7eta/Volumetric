/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.ac by autoheader.  */

/* Define if debugging is enabled */
/* #undef DEBUG */

/* Define to 1 if X11 support is enabled. */
#define ENABLE_EGL_X11 1

/* Define to 1 to enable entrypoint patching in libGLdispatch. */
#define GLDISPATCH_ENABLE_PATCHING 1

/* Page size to align static dispatch stubs. */
/* #undef GLDISPATCH_PAGE_SIZE */

/* Define to 1 if libGLdispatch should use a TLS variable for the dispatch
   table. */
#define GLDISPATCH_USE_TLS 1

/* Define to 1 if struct dirent has a d_type member. */
#define HAVE_DIRENT_DTYPE 1

/* Define to 1 if you have the <dlfcn.h> header file. */
#define HAVE_DLFCN_H 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define to 1 if you have the <memory.h> header file. */
#define HAVE_MEMORY_H 1

/* Define to 1 if mincore is available. */
#define HAVE_MINCORE 1

/* Define if you have POSIX threads libraries and header files. */
#define HAVE_PTHREAD 1

/* Have PTHREAD_PRIO_INHERIT. */
#define HAVE_PTHREAD_PRIO_INHERIT 1

/* Define to 1 if the compiler supports pthreads rwlocks. */
#define HAVE_PTHREAD_RWLOCK_T 1

/* Define to 1 if the compiler supports RTLD_NOLOAD. */
#define HAVE_RTLD_NOLOAD 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if the compiler supports __sync intrinsic functions. */
#define HAVE_SYNC_INTRINSICS 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if typeof works with your compiler. */
#define HAVE_TYPEOF 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define to the sub-directory where libtool stores uninstalled libraries. */
#define LT_OBJDIR ".libs/"

/* Define if debugging is disabled */
#define NDEBUG /**/

/* Name of package */
#define PACKAGE "libglvnd"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "kbrenneman@nvidia.com"

/* Define to the full name of this package. */
#define PACKAGE_NAME "libglvnd"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "libglvnd 1.7.0"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "libglvnd"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "1.7.0"

/* Define to necessary symbol if this constant uses a non-standard name on
   your system. */
/* #undef PTHREAD_CREATE_JOINABLE */

/* Define to 1 if you have the ANSI C header files. */
#define STDC_HEADERS 1

/* Define to 1 if the compiler supports constructor attributes. */
#define USE_ATTRIBUTE_CONSTRUCTOR 1

/* Define to 1 if libGLdispatch and libGLX should use assembly dispatch
   functions. */
#define USE_DISPATCH_ASM 1

/* Enable extensions on AIX 3, Interix.  */
#ifndef _ALL_SOURCE
# define _ALL_SOURCE 1
#endif
/* Enable GNU extensions on systems that have them.  */
#ifndef _GNU_SOURCE
# define _GNU_SOURCE 1
#endif
/* Enable threading extensions on Solaris.  */
#ifndef _POSIX_PTHREAD_SEMANTICS
# define _POSIX_PTHREAD_SEMANTICS 1
#endif
/* Enable extensions on HP NonStop.  */
#ifndef _TANDEM_SOURCE
# define _TANDEM_SOURCE 1
#endif
/* Enable general extensions on Solaris.  */
#ifndef __EXTENSIONS__
# define __EXTENSIONS__ 1
#endif


/* Version number of package */
#define VERSION "1.7.0"

/* Define to 1 if on MINIX. */
/* #undef _MINIX */

/* Define to 2 if the system does not provide POSIX.1 features except with
   this defined. */
/* #undef _POSIX_1_SOURCE */

/* Define to 1 if you need to in order for `stat' and other things to work. */
/* #undef _POSIX_SOURCE */

/* Define to __typeof__ if your compiler spells it that way. */
/* #undef typeof */
